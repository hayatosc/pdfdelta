import gzip, hashlib, json, os, shutil, subprocess, sys
from pathlib import Path
REPO = Path('/home/hayato/ghq/github.com/hayatosc/pdfdelta')
ROOT = REPO/'benchmark/realworld/cache/native-12-of-36-2026-09-20'
D = REPO/'benchmark/realworld/results/native-12-of-36-2026-09-20/h33-storage-dedup'
def sha256(path):
    h = hashlib.sha256()
    with open(path, 'rb') as f:
        for c in iter(lambda: f.read(1 << 20), b''):
            h.update(c)
    return h.hexdigest()
inventory = [json.loads(l) for l in gzip.open(D/'readonly-inventory.jsonl.gz', 'rt').read().splitlines()]
mismatch = []
for entry in inventory:
    p = REPO/entry['path']
    if not p.is_file():
        mismatch.append((entry['path'], 'missing'))
    elif os.lstat(p).st_size != entry['bytes']:
        mismatch.append((entry['path'], 'size'))
    elif sha256(p) != entry['sha256']:
        mismatch.append((entry['path'], 'sha'))
result = {'paths': len(inventory), 'mismatches': mismatch}
dry = subprocess.run([sys.executable, str(REPO/'benchmark/realworld/remaining/completion-investigation/dedup_reports.py'), str(ROOT)], capture_output=True, text=True)
result['post_dry_run'] = json.loads(dry.stdout.splitlines()[0])
sys.path.insert(0, str(REPO/'benchmark/realworld/remaining/completion-investigation'))
import housekeeping
result['managed_unique_inode_bytes'] = housekeeping.managed_cache_bytes(ROOT)
result['du_bytes'] = int(subprocess.check_output(['du', '-sb', str(ROOT)], text=True).split()[0])
result['df_free_bytes'] = shutil.disk_usage(REPO).free
events = Path('/sys/fs/cgroup/user.slice/user-1000.slice/user@1000.service/pdfdelta.slice/pdfdelta-heavy.slice/memory.events')
result['parent_memory_events'] = events.read_text() if events.is_file() else 'unavailable'
with gzip.open(D/'post-apply-verify.json.gz', 'wt') as f:
    f.write(json.dumps(result, sort_keys=True, indent=2) + '\n')
print(json.dumps({k: result[k] for k in ('paths', 'mismatches', 'managed_unique_inode_bytes', 'du_bytes', 'df_free_bytes')}, sort_keys=True))
print('post_dry_run', {k: result['post_dry_run'][k] for k in ('groups', 'candidate_bytes', 'replaced', 'already_shared')}, 'errors', len(result['post_dry_run']['errors']))
print('parent_memory_events', result['parent_memory_events'].strip().replace('\n', '; '))
if (
    result['mismatches']
    or result['post_dry_run']['errors']
    or result['post_dry_run']['candidate_bytes'] != 0
):
    raise SystemExit(1)
