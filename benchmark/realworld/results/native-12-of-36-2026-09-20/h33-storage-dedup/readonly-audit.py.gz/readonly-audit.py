import gzip
import hashlib
import json
import os
import shutil
import subprocess
import sys
from pathlib import Path

REPO = Path("/home/hayato/ghq/github.com/hayatosc/pdfdelta")
CACHE = REPO / "benchmark/realworld/cache/native-12-of-36-2026-09-20"
EVIDENCE = REPO / "benchmark/realworld/results/native-12-of-36-2026-09-20/h33-census-native"
TARGETS = [
    CACHE / "h29-raw-cut-only-full-iteration-016-native",
    CACHE / "h32-suffix-full-iteration-017-native",
    CACHE / "h32-final-targeted-native",
]
CHUNK = 1 << 20


def sha256_file(path):
    digest = hashlib.sha256()
    with open(path, "rb") as handle:
        for chunk in iter(lambda: handle.read(CHUNK), b""):
            digest.update(chunk)
    return digest.hexdigest()


def main():
    EVIDENCE.mkdir(parents=True, exist_ok=True)
    dry_run = subprocess.run(
        [sys.executable, str(REPO / "benchmark/realworld/remaining/completion-investigation/dedup_reports.py"), str(CACHE)],
        capture_output=True,
        text=True,
    )
    with gzip.open(EVIDENCE / "dedup-dry-run-readonly.json.gz", "wt") as handle:
        handle.write(dry_run.stdout)
        handle.write(dry_run.stderr)
    print("dry_run_rc", dry_run.returncode)

    inventory = []
    for target in TARGETS:
        for path in sorted(target.rglob("*.json.gz")):
            if path.is_symlink() or not path.is_file():
                continue
            stat = os.lstat(path)
            inventory.append(
                {
                    "path": str(path.relative_to(REPO)),
                    "bytes": stat.st_size,
                    "sha256": sha256_file(path),
                }
            )
    with gzip.open(EVIDENCE / "readonly-inventory.jsonl.gz", "wt") as handle:
        for entry in inventory:
            handle.write(json.dumps(entry, sort_keys=True) + "\n")
    print("inventoried", len(inventory))

    sys.path.insert(0, str(REPO / "benchmark/realworld/remaining/completion-investigation"))
    import housekeeping

    snapshot = {
        "managed_unique_inode_bytes": housekeeping.managed_cache_bytes(CACHE),
        "du_bytes": int(subprocess.check_output(["du", "-sb", str(CACHE)], text=True).split()[0]),
        "df_free_bytes": shutil.disk_usage(REPO).free,
        "memory_events": Path("/sys/fs/cgroup" + Path("/proc/self/cgroup").read_text().strip().split(":")[-1] + "/memory.events").read_text()
        if Path("/proc/self/cgroup").read_text().strip().split(":")[-1]
        else "unavailable",
        "inventory_entries": len(inventory),
        "inventory_bytes": sum(entry["bytes"] for entry in inventory),
    }
    for target in TARGETS:
        summary = target / "summary.json"
        if summary.is_file():
            data = json.loads(summary.read_text())
            snapshot[target.name] = {
                "binary_sha256": data.get("binary", {}).get("sha256"),
                "head": data.get("head"),
                "summary_sha256": sha256_file(summary),
                "production_archive_sha256": sha256_file(target / "production.tar.gz")
                if (target / "production.tar.gz").is_file()
                else None,
            }
    with gzip.open(EVIDENCE / "readonly-snapshot.json.gz", "wt") as handle:
        handle.write(json.dumps(snapshot, sort_keys=True, indent=2) + "\n")
    print(json.dumps({k: v for k, v in snapshot.items() if k != "memory_events"}, sort_keys=True))
    print("memory_events", snapshot["memory_events"].strip().replace("\n", "; "))


if __name__ == "__main__":
    main()
