import gzip
import sys
from pathlib import Path

import ijson

SKIP = {"assessment.work_used", "assessment.work_by_stage"}


def skipped(prefix):
    return any(prefix == field or prefix.startswith(f"{field}.") for field in SKIP)


def stream(path, skip):
    with gzip.open(path, "rb") as handle:
        for prefix, event, value in ijson.parse(handle, use_float=True):
            if skip and skipped(prefix):
                continue
            yield (prefix, event, value)


def main(pair, new_path, base_path):
    new_events = stream(new_path, True)
    base_events = stream(base_path, True)
    count = 0
    while True:
        try:
            new = next(new_events)
        except StopIteration:
            new = None
        try:
            base = next(base_events)
        except StopIteration:
            base = None
        if new is None and base is None:
            break
        if new != base:
            print(f"{pair}: MISMATCH after {count} events")
            print("  new", new)
            print("  base", base)
            return 1
        count += 1
    print(f"{pair}: identical apart from work fields, events={count}")
    return 0


if __name__ == "__main__":
    pair, new_path, base_path = sys.argv[1:4]
    raise SystemExit(main(pair, Path(new_path), Path(base_path)))
