import gzip
import json
import sys
from pathlib import Path

import ijson

ROOT = Path("benchmark/realworld/cache/native-12-of-36-2026-09-20")
PAIR = "irs-1099-misc-2024-to-2025"
NEW = ROOT / "h32-suffix-targeted-native" / PAIR / f"{PAIR}-native.json.gz"
BASE = ROOT / "h29-raw-cut-only-full-iteration-016-native" / PAIR / f"{PAIR}-native.json.gz"
OLD_SUFFIX = (226, 1462, 2085)
NEW_SUFFIX = (225, 1338, 1961)
OLD_BLOCKS = {226, 227, 228}
NEW_BLOCKS = {225, 226, 227}


def canon(value):
    return json.dumps(value, sort_keys=True, separators=(",", ":"))


def items(path, key):
    with gzip.open(path, "rb") as handle:
        yield from ijson.items(handle, key, use_float=True)


def blocks_of(span):
    return set(span["blocks"]) if span else set()


def first_block(span):
    return span["blocks"][0]


def load_relations(path):
    return list(items(path, "assessment.relations.item"))


def load_review_units(path):
    return list(items(path, "assessment.review_units.item"))


def load_resolution(path, side):
    return list(items(path, f"assessment.{side}_resolution.item"))


def load_unresolved(path):
    return list(items(path, "unresolved_regions.item"))


def unresolved_blocks(regions):
    per_side_block = {}
    for region in regions:
        for side in ("old_span", "new_span"):
            span = region.get(side)
            if span is None:
                continue
            for block in span["blocks"]:
                per_side_block.setdefault((side, block), []).append(span["comparable_range"])
    return per_side_block


new_relations = load_relations(NEW)
base_relations = load_relations(BASE)
assert len(base_relations) == 937, len(base_relations)
assert len(new_relations) == 938, len(new_relations)
for index, (new, base) in enumerate(zip(new_relations, base_relations)):
    assert canon(new) == canon(base), f"relation {index} changed"
suffix = new_relations[-1]
assert suffix["assumptions"] == ["rigid_suffix_translation"], suffix["assumptions"]
assert suffix["outcome"] == "established" and suffix["search"] == "complete"
for side, (block, start, end) in (("old_span", OLD_SUFFIX), ("new_span", NEW_SUFFIX)):
    span = suffix[side]
    assert span["blocks"] == [block], span["blocks"]
    assert span["comparable_range"] == {"start": start, "end": end}, span["comparable_range"]
    assert span["canonical_range"] == {"start": start, "end": end}, span["canonical_range"]
print("relations: 937 ordered base records retained, one 623-token suffix record appended")

new_units = load_review_units(NEW)
base_units = load_review_units(BASE)
assert len(base_units) == 9 and len(new_units) == 2
retained = [canon(unit) for unit in base_units if canon(unit) in {canon(u) for u in new_units}]
assert retained == [canon(unit) for unit in new_units], "retained review unit order or multiplicity changed"
removed = [unit for unit in base_units if canon(unit) not in {canon(u) for u in new_units}]
assert len(removed) == 7
print("review units: retained", [unit["relation"] for unit in new_units], "removed", [unit["relation"] for unit in removed])

old_resolution = load_resolution(NEW, "old")
new_resolution = load_resolution(NEW, "new")
for block, start, end in (OLD_SUFFIX, NEW_SUFFIX):
    matching = [
        entry
        for entry in (old_resolution if block == OLD_SUFFIX[0] else new_resolution)
        if entry["block"] == block
    ]
    assert matching, f"block {block} missing from after resolution"
    assert max(entry["canonical_range"]["end"] for entry in matching) == end
    assert any(
        entry["canonical_range"] == {"start": start, "end": end} and entry["state"] == "equal"
        for entry in matching
    ), f"block {block} suffix range not equal after"
print("resolution: both suffix blocks end exactly at the 623-token equal range")

before_unresolved = unresolved_blocks(load_unresolved(BASE))
after_unresolved = unresolved_blocks(load_unresolved(NEW))

for unit in removed:
    relation = base_relations[unit["relation"]]
    for side, (suffix_block, suffix_start, suffix_end), resolution, before_side in (
        ("old_span", OLD_SUFFIX, old_resolution, load_resolution(BASE, "old")),
        ("new_span", NEW_SUFFIX, new_resolution, load_resolution(BASE, "new")),
    ):
        span = relation[side]
        assert span is not None, (unit["relation"], side)
        blocks = span["blocks"]
        assert blocks[0] == suffix_block, (unit["relation"], side, blocks)
        assert span["comparable_range"]["start"] >= suffix_start, (unit["relation"], side)
        for block in blocks[1:]:
            entries = sorted(
                (entry for entry in resolution if entry["block"] == block),
                key=lambda entry: entry["canonical_range"]["start"],
            )
            assert entries, (unit["relation"], side, block, "empty after resolution")
            cursor = 0
            for entry in entries:
                assert entry["comparable_range"] == entry["canonical_range"], (unit["relation"], side, block)
                span_range = entry["canonical_range"]
                assert span_range["start"] == cursor, (unit["relation"], side, block, span_range)
                assert span_range["end"] > span_range["start"], (unit["relation"], side, block)
                assert entry["state"] in ("equal", "changed"), (unit["relation"], side, block, entry["state"])
                assert entry.get("sources"), (unit["relation"], side, block, "no source evidence")
                cursor = span_range["end"]
            assert cursor > 0, (unit["relation"], side, block)
            anchors = [
                (index, relation)
                for index, relation in enumerate(base_relations)
                if relation.get("outcome") == "established"
                and relation.get(side) is not None
                and relation[side]["blocks"] == [block]
                and relation[side]["comparable_range"] == {"start": 0, "end": cursor}
                and relation[side]["canonical_range"] == {"start": 0, "end": cursor}
            ]
            assert anchors, (unit["relation"], side, block, cursor, "no whole anchor")
            anchor_index, anchor = anchors[0]
            print(
                "  following block",
                side,
                block,
                "length",
                cursor,
                "anchor relation",
                anchor_index,
                "states",
                [entry["state"] for entry in entries],
            )
            before_entries = sorted(
                (entry for entry in before_side if entry["block"] == block),
                key=lambda entry: entry["canonical_range"]["start"],
            )
            assert [canon(entry) for entry in before_entries] == [
                canon(entry) for entry in entries
            ], (unit["relation"], side, block, "following block resolution changed")
            assert not before_unresolved.get((side, block)), (unit["relation"], side, block)
            assert not after_unresolved.get((side, block)), (unit["relation"], side, block)
print("removed review units: first block is the suffix block, start inside it;")
print("every following block is a contiguous, source-evidenced full equal/changed partition")
print("CERTIFICATE PASS (containing-range coverage proof; virtual separators add no source token)")
