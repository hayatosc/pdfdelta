import gzip, json
from pathlib import Path
import ijson
D=Path('benchmark/realworld/results/native-12-of-36-2026-09-20/h37-bracket-generalization')
ret=json.loads(gzip.open(D/'retention-irs-w2-2024-to-2025.json.gz','rt').read())
print('problems', len(ret.get('problems',[])))
for p in ret.get('problems',[])[:6]:
    print(json.dumps(p, sort_keys=True)[:300])
cache=Path('benchmark/realworld/cache/native-12-of-36-2026-09-20')
new=cache/'h37-bracket-native/irs-w2-2024-to-2025/irs-w2-2024-to-2025-native.json.gz'
base=cache/'h32-suffix-full-iteration-017-native/irs-w2-2024-to-2025/irs-w2-2024-to-2025-native.json.gz'
def work(path):
    with gzip.open(path,'rb') as f:
        a=next(ijson.items(f,'assessment.work_used'))
    with gzip.open(path,'rb') as f:
        b=next(ijson.items(f,'assessment.work_by_stage'))
    return a,b
nw,nbs=work(new); bw,bbs=work(base)
print('work_used new',nw,'base',bw)
print('stage new',json.dumps(nbs,sort_keys=True)[:300])
print('stage base',json.dumps(bbs,sort_keys=True)[:300])
def unresolved(path):
    with gzip.open(path,'rb') as f:
        return list(ijson.items(f,'unresolved_regions.item'))
nu=unresolved(new); bu=unresolved(base)
def key(item):
    for side in ('old_span','new_span'):
        s=item.get(side)
        if s: return (side, tuple(s['blocks']), s['comparable_range']['start'], s['comparable_range']['end'])
    return None
nset={key(i) for i in nu}; bset={key(i) for i in bu}
lost=sorted(bset-nset, key=str)[:8]; gained=sorted(nset-bset, key=str)[:8]
print('unresolved lost (base not in new)', len(bset-nset))
for k in lost: print('  LOST', k)
print('unresolved gained (new not in base)', len(nset-bset))
for k in gained: print('  GAINED', k)
