import gzip, json
from collections import defaultdict
from pathlib import Path
import ijson
cache=Path('benchmark/realworld/cache/native-12-of-36-2026-09-20')
new=cache/'h37-bracket-native/irs-w2-2024-to-2025/irs-w2-2024-to-2025-native.json.gz'
base=cache/'h32-suffix-full-iteration-017-native/irs-w2-2024-to-2025/irs-w2-2024-to-2025-native.json.gz'
def tokens(path, side):
    out=set()
    with gzip.open(path,'rb') as f:
        for item in ijson.items(f, f'assessment.{side}_resolution.item'):
            if item.get('state') in ('equal','changed'):
                for offset in range(item['canonical_range']['start'], item['canonical_range']['end']):
                    out.add((item['block'], offset))
    return out
def ranges(token_set):
    per_block=defaultdict(list)
    for block, offset in sorted(token_set):
        per_block[block].append(offset)
    out=[]
    for block, offsets in sorted(per_block.items()):
        start=prev=offsets[0]
        for offset in offsets[1:]:
            if offset == prev + 1:
                prev = offset
            else:
                out.append([block, start, prev+1]); start=prev=offset
        out.append([block, start, prev+1])
    return out
result={}
for side in ('old','new'):
    n=tokens(new, side); b=tokens(base, side)
    lost=b-n; gained=n-b
    result[side]={'lost_tokens':len(lost),'gained_tokens':len(gained),
                  'lost_ranges':ranges(lost),'gained_ranges':ranges(gained)}
    print(side,'lost',len(lost),'gained',len(gained))
    assert len(lost)==752,(side,len(lost))
    assert len(gained)==0,(side,len(gained))
D=Path('benchmark/realworld/results/native-12-of-36-2026-09-20/h37-bracket-generalization')
with gzip.open(D/'h37-w2-loss.json.gz','wt') as f:
    f.write(json.dumps(result,sort_keys=True,indent=2)+'\n')
print('exact loss verified 752/0 per side')
