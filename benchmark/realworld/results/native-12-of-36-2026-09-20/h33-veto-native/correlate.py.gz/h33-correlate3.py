import gzip
import hashlib
import json
from collections import defaultdict
from pathlib import Path

import ijson

D = Path("benchmark/realworld/results/native-12-of-36-2026-09-20/h33-veto-native")
CENSUS = Path("benchmark/realworld/results/native-12-of-36-2026-09-20/h33-census-native/census.jsonl.gz")
REPORT = Path(
    "benchmark/realworld/cache/native-12-of-36-2026-09-20/h33-veto-native/"
    "irs-1099-misc-2024-to-2025/irs-1099-misc-2024-to-2025-native.json.gz"
)
EXPECTED_LOGICAL = "7964e3b5179c00edcc9a229b71bc0e9483c9975cf8204f92e51b06689a5773b2"

trace = [json.loads(line) for line in gzip.open(D / "retry-veto-trace.jsonl.gz", "rt").read().splitlines()]
segments = [
    row
    for row in (json.loads(line) for line in gzip.open(CENSUS, "rt").read().splitlines())
    if row.get("kind") == "segment"
]
assert len(trace) == 95, len(trace)
assert len(segments) == 117, len(segments)
census_sha = hashlib.sha256(CENSUS.read_bytes()).hexdigest()

logical = hashlib.sha256()
with gzip.open(REPORT, "rb") as handle:
    for chunk in iter(lambda: handle.read(1 << 20), b""):
        logical.update(chunk)
assert logical.hexdigest() == EXPECTED_LOGICAL, logical.hexdigest()
census_runs = json.loads(
    Path(
        "benchmark/realworld/cache/native-12-of-36-2026-09-20/h33-census-native/"
        "irs-1099-misc-2024-to-2025/runs.json"
    ).read_text()
)["runs"][0]
census_logical = census_runs.get("logical_report_sha256") or census_runs.get("report_sha256")
assert census_logical == EXPECTED_LOGICAL, census_logical

for side in (0, 1):
    side_segments = sorted(
        (segment for segment in segments if segment["side"] == side),
        key=lambda segment: (segment["block"], segment["start"]),
    )
    cursor = {}
    total = 0
    for segment in side_segments:
        block = segment["block"]
        start = cursor.get(block, 0)
        assert segment["start"] >= start, (side, block, segment["start"], start)
        cursor[block] = segment["end"]
        assert segment["len"] == segment["end"] - segment["start"] > 0, segment
        total += segment["len"]
    assert total == (1044 if side == 0 else 797), (side, total)

relations_of_interest = {row["relation"] for row in trace} | {299, 300, 783, 784}
records = {}
with gzip.open(REPORT, "rb") as handle:
    for index, relation in enumerate(ijson.items(handle, "assessment.relations.item", use_float=True)):
        if index in relations_of_interest:
            records[index] = relation
assert set(records) == relations_of_interest, (relations_of_interest - set(records))

def span_tuple(span):
    return (
        span["blocks"],
        span["canonical_range"]["start"],
        span["canonical_range"]["end"],
        span["comparable_range"]["start"],
        span["comparable_range"]["end"],
    )

for row in trace:
    record = records[row["relation"]]
    for side, blocks_key, range_key, canonical_key, span_key in (
        (0, "old_blocks", "old_range", "old_canonical", "old_span"),
        (1, "new_blocks", "new_range", "new_canonical", "new_span"),
    ):
        span = record.get(span_key)
        assert span is not None, (row["relation"], span_key)
        assert span["blocks"] == row[blocks_key], (row["relation"], side, span["blocks"], row[blocks_key])
        assert span["comparable_range"]["start"] == row[range_key][0], (row["relation"], side)
        assert span["comparable_range"]["end"] == row[range_key][1], (row["relation"], side)
        assert span["canonical_range"]["start"] == row[canonical_key][0], (row["relation"], side)
        assert span["canonical_range"]["end"] == row[canonical_key][1], (row["relation"], side)

def without_parent(record):
    return {key: value for key, value in record.items() if key != "parent"}

assert records[300]["parent"] == 299, records[300]["parent"]
assert records[784]["parent"] == 783, records[784]["parent"]
assert without_parent(records[299]) == without_parent(records[300])
assert without_parent(records[783]) == without_parent(records[784])

by_relation = defaultdict(list)
for row in trace:
    by_relation[row["relation"]].append(row)

hold_tokens = {0: defaultdict(int), 1: defaultdict(int)}
segment_rows = []
for segment in segments:
    ids = set()
    for key in ("eq_ids", "ch_ids", "other_ids"):
        ids.update(int(value) for value in segment.get(key, "").split(",") if value)
    matched = sorted(
        {
            (row["relation"], row["label"], row["hold"])
            for relation in ids
            for row in by_relation.get(relation, [])
        }
    )
    for label, hold in sorted({(label, hold) for _, label, hold in matched}):
        hold_tokens[segment["side"]][(label, hold)] += segment["len"]
    segment_rows.append(
        {
            "side": segment["side"],
            "block": segment["block"],
            "start": segment["start"],
            "end": segment["end"],
            "len": segment["len"],
            "class": segment["class"],
            "ids": sorted(ids),
            "matched": [
                {"relation": relation, "label": label, "hold": hold}
                for relation, label, hold in matched
            ],
        }
    )

coverage = {}
for side in (0, 1):
    unowned = sum(segment["len"] for segment in segments if segment["side"] == side)
    covered = sum(row["len"] for row in segment_rows if row["side"] == side and row["matched"])
    coverage[str(side)] = {
        "unowned": unowned,
        "covered": covered,
        "unknown": unowned - covered,
    }
    print("side", side, coverage[str(side)])
    for (label, hold), tokens in sorted(hold_tokens[side].items()):
        print("   ", label, hold, tokens)
for row in segment_rows:
    if row["matched"]:
        print("MATCHED-SEGMENT", json.dumps(row, sort_keys=True))

summary = {
    "trace_rows": len(trace),
    "segments": len(segments),
    "census_sha256": census_sha,
    "report_logical_sha256": logical.hexdigest(),
    "parent_links": {"300": records[300]["parent"], "784": records[784]["parent"]},
    "pairs_identical_except_parent": True,
    "coverage": coverage,
    "holds": {
        str(side): {f"{label}|{hold}": tokens for (label, hold), tokens in hold_tokens[side].items()}
        for side in (0, 1)
    },
    "matched_segments": [row for row in segment_rows if row["matched"]],
}
with gzip.open(D / "correlate-summary.json.gz", "wt") as handle:
    handle.write(json.dumps(summary, sort_keys=True, indent=2) + "\n")
print("SUMMARY", json.dumps({k: summary[k] for k in ("trace_rows", "segments", "parent_links", "coverage")}, sort_keys=True))
