import gzip, json
from collections import defaultdict
from pathlib import Path
D = Path('benchmark/realworld/results/native-12-of-36-2026-09-20/h34-veto-native')
rows = [json.loads(l) for l in gzip.open(D/'h34-trace.jsonl.gz','rt').read().splitlines()]
segments = [json.loads(l) for l in gzip.open('benchmark/realworld/results/native-12-of-36-2026-09-20/h33-census-native/census.jsonl.gz','rt').read().splitlines()]
segments = [s for s in segments if s.get('kind') == 'segment']
domain = {r['relation']: r for r in rows if r['kind'] == 'domain-record'}
child_by_id = {}
for r in rows:
    if r['kind'] == 'child-record':
        child_by_id[r['relation']] = r
child_ids = set(child_by_id)
local = defaultdict(list)
for r in rows:
    if r['kind'] == 'local-veto':
        local[r['relation']].append(r)
out = []
for segment in segments:
    ids = set()
    for key in ('eq_ids','ch_ids','other_ids'):
        ids.update(int(v) for v in segment.get(key,'').split(',') if v)
    matched = []
    for i in sorted(ids):
        if i in domain:
            r = domain[i]
            matched.append({'record': i, 'kind': 'domain-record', 'relation': r['relation'], 'parent': r['parent'], 'label': r['label'], 'detail': r['detail']})
        if i in child_ids:
            c = child_by_id[i]
            matched.append({'record': c['relation'], 'kind': 'child-record', 'relation': c['relation'], 'parent': c['parent'], 'label': c['label'], 'detail': c['detail'], 'note': 'relation-id membership only; parent kept as annotation'})
        for l in local.get(i, []):
            matched.append({'record': l['relation'], 'kind': 'local-veto', 'relation': l['relation'], 'parent': None, 'label': l['label'], 'detail': l['detail']})
    out.append({'side': segment['side'], 'block': segment['block'], 'start': segment['start'], 'end': segment['end'], 'len': segment['len'], 'class': segment['class'], 'ids': sorted(ids), 'matched': matched})
covered = {0: 0, 1: 0}
for row in out:
    if row['matched']:
        covered[row['side']] += row['len']
with gzip.open(D/'h34-correlate.json.gz','wt') as f:
    f.write(json.dumps({'covered': covered, 'segments': out}, sort_keys=True, indent=2)+'\n')
for row in out:
    if row['matched'] and row['len'] >= 16:
        print(json.dumps(row, sort_keys=True)[:500])
print('covered', covered)
