import gzip, json
from pathlib import Path
import ijson
REPORT = Path('benchmark/realworld/cache/native-12-of-36-2026-09-20/h34-veto-native/irs-1099-misc-2024-to-2025/irs-1099-misc-2024-to-2025-native.json.gz')
D = Path('benchmark/realworld/results/native-12-of-36-2026-09-20/h34-veto-native')
TARGET = 'File with Form 1096.'

def scope(span, text=None):
    if span is None:
        return None
    body = text if text is not None else (span.get('text') or '')
    return {
        'blocks': span.get('blocks'),
        'block_separator': span.get('block_separator'),
        'canonical_range': span.get('canonical_range'),
        'comparable_range': span.get('comparable_range'),
        'pages': span.get('pages'),
        'text_len': len(body),
        'text_head': body[:120],
        'text_tail': body[-120:],
        'sources_count': len(span.get('sources', [])),
    }

def offsets(text):
    out = []
    start = text.find(TARGET)
    while start != -1:
        out.append(start)
        start = text.find(TARGET, start + 1)
    return out

record0 = {}
occurrences = []
block32_sources = []
new_unresolved = []
with gzip.open(REPORT, 'rb') as handle:
    for item in ijson.items(handle, 'unresolved_regions.item', use_float=True):
        old = item.get('old_span')
        new = item.get('new_span')
        if old and old.get('blocks') == [32] and old.get('text') == TARGET:
            block32_sources = [
                {'glyph_id': s.get('glyph_id'), 'page': s.get('page'), 'operator_index': s.get('operator_index'), 'content_stream': s.get('content_stream'), 'bbox': s.get('bbox'), 'kind': s.get('kind')}
                for s in old.get('sources', [])
            ]
        if new and isinstance(new.get('blocks'), list) and len(new['blocks']) == 1:
            body = new.get('text') or ''
            found = offsets(body)
            new_unresolved.append({'evidence': item.get('evidence'), 'scope': scope(new), 'offsets': found})
with gzip.open(REPORT, 'rb') as handle:
    for index, relation in enumerate(ijson.items(handle, 'assessment.relations.item', use_float=True)):
        for key in ('old_span', 'new_span'):
            span = relation.get(key)
            if span is None:
                continue
            body = span.get('text') or ''
            found = offsets(body)
            if index == 0:
                record0[key] = scope(span, body)
            for offset in found:
                occurrences.append({
                    'relation': index,
                    'key': key,
                    'char_offset': offset,
                    'scope': scope(span),
                    'context': body[max(0, offset-25):offset+len(TARGET)+25],
                })
print('record0 old_len', record0.get('old_span', {}).get('text_len'), 'new_len', record0.get('new_span', {}).get('text_len'))
print('record0 old blocks', (record0.get('old_span') or {}).get('blocks', [])[:3], '...', (record0.get('old_span') or {}).get('blocks', [])[-3:])
print('record0 new blocks', (record0.get('new_span') or {}).get('blocks', [])[:3], '...', (record0.get('new_span') or {}).get('blocks', [])[-3:])
print('occurrences', len(occurrences), 'distinct spans', len({(o['relation'], o['key']) for o in occurrences}))
print('occurrence keys', sorted({o['key'] for o in occurrences}))
print('block32 sources', len(block32_sources))
if block32_sources:
    print(' first', json.dumps(block32_sources[0], sort_keys=True))
    print(' last', json.dumps(block32_sources[-1], sort_keys=True))
print('new single-block unresolved', len(new_unresolved), 'with target offsets', sum(1 for row in new_unresolved if row['offsets']))
with gzip.open(D/'block32-substring-probe.json.gz', 'wt') as f:
    f.write(json.dumps({'record0': record0, 'target': TARGET, 'occurrences': occurrences, 'new_single_block_unresolved': new_unresolved, 'block32_sources': block32_sources}, sort_keys=True, indent=2) + '\n')
