import gzip, json
from pathlib import Path
import ijson
cache=Path('benchmark/realworld/cache/native-12-of-36-2026-09-20')
out={}
for level in ('32000000','64000000','128000000'):
    report=cache/f'h38-w4-work-{level}/irs-w4-english-2024-to-2025/irs-w4-english-2024-to-2025-native.json.gz'
    with gzip.open(report,'rb') as f:
        work=next(ijson.items(f,'assessment.work_used'))
    with gzip.open(report,'rb') as f:
        stages=next(ijson.items(f,'assessment.work_by_stage'))
    parts={'old115':[],'new205':[]}
    with gzip.open(report,'rb') as f:
        for item in ijson.items(f,'assessment.old_resolution.item'):
            if item['block']==115:
                parts['old115'].append((item['canonical_range']['start'],item['canonical_range']['end'],item.get('state')))
    with gzip.open(report,'rb') as f:
        for item in ijson.items(f,'assessment.new_resolution.item'):
            if item['block']==205:
                parts['new205'].append((item['canonical_range']['start'],item['canonical_range']['end'],item.get('state')))
    rels=[]
    with gzip.open(report,'rb') as f:
        for i,rel in enumerate(ijson.items(f,'assessment.relations.item')):
            for key,blocks in (('old_span',[115]),('new_span',[205])):
                s=rel.get(key)
                if s and s['blocks']==blocks:
                    rels.append({'relation':i,'key':key,'range':s['comparable_range'],'outcome':rel.get('outcome'),
                                 'search':rel.get('search'),'reasons':rel.get('reasons'),'assumptions':rel.get('assumptions'),'parent':rel.get('parent')})
    out[level]={'work_used':work,'work_by_stage':stages,'partitions':parts,'relations':rels}
    print(level,'work_used',work,'stages',json.dumps(stages,sort_keys=True))
    print('  old115',parts['old115'][:6])
    print('  new205',parts['new205'][:6])
    for r in rels[:8]: print('  REL',json.dumps(r,sort_keys=True)[:280])
Path('/tmp/opencode/h38-ladder.json').write_text(json.dumps(out,sort_keys=True,indent=2))
