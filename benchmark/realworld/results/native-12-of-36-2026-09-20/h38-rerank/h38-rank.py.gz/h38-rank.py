import gzip, json
from collections import Counter
from pathlib import Path
import ijson
cache=Path('benchmark/realworld/cache/native-12-of-36-2026-09-20/h32-suffix-full-iteration-017-native')
pairs=['irs-schedule-c-2024-to-2025','irs-1099-misc-2024-to-2025','faa-thunderstorms-b-to-c','faa-maintenance-records-c-to-d','nasa-buckling-8007-1968-to-2020','irs-w2-2024-to-2025']
out={}
for pair in pairs:
    report=cache/pair/f'{pair}-native.json.gz'
    if not report.is_file():
        print(pair,'missing'); continue
    with gzip.open(report,'rb') as f:
        summary=next(ijson.items(f,'summary',use_float=True))
    with gzip.open(report,'rb') as f:
        kinds=Counter()
        for item in ijson.items(f,'unresolved_regions.item',use_float=True):
            for e in item.get('evidence',[]): kinds[e]+=1
    entry={'complete':summary.get('comparison_complete'),
           'old':summary.get('old_alignment_coverage'),'new':summary.get('new_alignment_coverage'),
           'unresolved_regions':summary.get('unresolved_regions'),
           'content_changes':summary.get('content_changes'),'tentative_candidates':summary.get('tentative_candidates'),
           'proven':summary.get('proven_changed_regions'),'reasons':dict(kinds)}
    out[pair]=entry
    print(pair, json.dumps(entry,sort_keys=True))
Path('/tmp/opencode/h38-rank.json').write_text(json.dumps(out,sort_keys=True,indent=2))
