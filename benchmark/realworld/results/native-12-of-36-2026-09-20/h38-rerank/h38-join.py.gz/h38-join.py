import gzip, json
from pathlib import Path
R=Path('benchmark/realworld/results/native-12-of-36-2026-09-20')
cache=Path('benchmark/realworld/cache/native-12-of-36-2026-09-20/h32-suffix-full-iteration-017-native')
score=json.loads(gzip.open(R/'h38-rerank/h38-scorecard36.json.gz','rt').read())
capture=json.loads((cache/'summary.json').read_text())
panel=json.loads(Path('benchmark/realworld/followup/panel.json').read_text())
panel_ids={p['id'] for p in panel['pairs']}
capture_ids={row['pair'] for row in capture['rows']}
score_ids={row['pair'] for row in score['all']}
assert score_ids == capture_ids, (score_ids ^ capture_ids)
assert score_ids == panel_ids, (score_ids ^ panel_ids)
rows={row['pair']: dict(row) for row in capture['rows']}
joined=[]
for entry in score['all']:
    row=rows[entry['pair']]
    entry.update({
        'old_extraction_complete': row.get('old_extraction_complete'),
        'new_extraction_complete': row.get('new_extraction_complete'),
        'unsupported_extraction_issues': row.get('unsupported_extraction_issues'),
        'unresolved_extraction_issues': row.get('unresolved_extraction_issues'),
        'candidates_truncated': row.get('candidates_truncated'),
        'formatting_only_changes': row.get('formatting_only_changes'),
        'uncertain_changes': row.get('uncertain_changes'),
    })
    joined.append(entry)
incomplete=[r for r in joined if not r['complete']]
out={**score,'all':joined,
     'top_by_unowned':sorted(incomplete,key=lambda r:r['unowned'])[:10],
     'top_by_unresolved':sorted(incomplete,key=lambda r:r['unresolved_regions'])[:10]}
with gzip.open(R/'h38-rerank/h38-scorecard36.json.gz','wt') as f:
    f.write(json.dumps(out,sort_keys=True,indent=2)+'\n')
print('join ok; pairs', len(joined))
print('extraction-incomplete among top_by_unowned:')
for r in out['top_by_unowned']:
    if not (r.get('old_extraction_complete') and r.get('new_extraction_complete')) or r.get('unsupported_extraction_issues') or r.get('unresolved_extraction_issues'):
        print(' ', r['pair'], 'old_complete', r.get('old_extraction_complete'), 'new_complete', r.get('new_extraction_complete'),
              'unsupported', r.get('unsupported_extraction_issues'), 'unresolved_issues', r.get('unresolved_extraction_issues'))
print('extraction-complete top_by_unowned candidates:')
for r in out['top_by_unowned']:
    if r.get('old_extraction_complete') and r.get('new_extraction_complete') and not r.get('unsupported_extraction_issues') and not r.get('unresolved_extraction_issues'):
        print(' ', r['pair'], 'unowned', r['unowned'], 'unresolved', r['unresolved_regions'], 'truncated', r.get('candidates_truncated'))
