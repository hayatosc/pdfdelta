import gzip, json
from collections import defaultdict
from pathlib import Path
import ijson
R=Path('benchmark/realworld/results/native-12-of-36-2026-09-20')
cache=Path('benchmark/realworld/cache/native-12-of-36-2026-09-20/h32-suffix-full-iteration-017-native')
pair='irs-w4-english-2024-to-2025'
report=cache/pair/f'{pair}-native.json.gz'
with gzip.open(report,'rb') as f:
    work=next(ijson.items(f,'assessment.work_used'))
with gzip.open(report,'rb') as f:
    stages=next(ijson.items(f,'assessment.work_by_stage'))
with gzip.open(report,'rb') as f:
    root=next(ijson.items(f,'assessment.relations.item'))
print('work_used',work); print('work_by_stage',json.dumps(stages,sort_keys=True))
print('root relation',json.dumps({k:root.get(k) for k in ('outcome','search','reasons','assumptions')},sort_keys=True))
unres=[]
with gzip.open(report,'rb') as f:
    for item in ijson.items(f,'unresolved_regions.item',use_float=True):
        span=item.get('old_span') or item.get('new_span')
        if span:
            unres.append({'side':'old' if item.get('old_span') else 'new','blocks':span['blocks'],
                          'range':span['comparable_range'],'evidence':item.get('evidence')})
unres.sort(key=lambda r:(r['range']['end']-r['range']['start']),reverse=True)
print('unresolved regions',len(unres))
for r in unres[:6]:
    print(' BIG', r['side'], r['blocks'][:4], r['range'], r['evidence'])
target=unres[0]
lo,hi=target['range']['start'],target['range']['end']
hits=[]
with gzip.open(report,'rb') as f:
    for i,rel in enumerate(ijson.items(f,'assessment.relations.item',use_float=True)):
        for key in ('old_span','new_span'):
            s=rel.get(key)
            if not s: continue
            if s['blocks']==target['blocks'] and s['comparable_range']['start']<hi and lo<s['comparable_range']['end']:
                hits.append({'relation':i,'key':key,'outcome':rel.get('outcome'),'search':rel.get('search'),
                             'reasons':rel.get('reasons'),'parent':rel.get('parent'),
                             'range':s['comparable_range'],'assumptions':rel.get('assumptions')})
print('relations overlapping largest range',len(hits))
for h in hits[:8]: print(' HIT', json.dumps(h,sort_keys=True)[:300])
