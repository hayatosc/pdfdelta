import gzip, json
from pathlib import Path
import ijson
R=Path('benchmark/realworld/results/native-12-of-36-2026-09-20')
cache=Path('benchmark/realworld/cache/native-12-of-36-2026-09-20/h32-suffix-full-iteration-017-native')
capture=json.loads((cache/'summary.json').read_text())
status={row['pair']: row.get('status') for row in capture['rows']}
rows=[]
for pair_dir in sorted(p for p in cache.iterdir() if p.is_dir()):
    pair=pair_dir.name
    report=pair_dir/f'{pair}-native.json.gz'
    if not report.is_file():
        continue
    with gzip.open(report,'rb') as f:
        summary=next(ijson.items(f,'summary',use_float=True))
    with gzip.open(report,'rb') as f:
        unresolved=sum(1 for _ in ijson.items(f,'unresolved_regions.item',use_float=True))
    old=summary.get('old_alignment_coverage') or {}
    new=summary.get('new_alignment_coverage') or {}
    rows.append({
        'pair':pair,'status':status.get(pair),
        'complete':summary.get('comparison_complete'),
        'old_total':old.get('total_tokens'),'old_resolved':old.get('resolved_tokens'),
        'new_total':new.get('total_tokens'),'new_resolved':new.get('resolved_tokens'),
        'unowned': (old.get('total_tokens',0)-old.get('resolved_tokens',0)) + (new.get('total_tokens',0)-new.get('resolved_tokens',0)),
        'unresolved_regions':unresolved,
        'content_changes':summary.get('content_changes'),'tentative_candidates':summary.get('tentative_candidates'),
        'proven':summary.get('proven_changed_regions'),
        'work':summary.get('work_used','unknown'),
    })
incomplete=[r for r in rows if not r['complete']]
by_unowned=sorted(incomplete,key=lambda r:r['unowned'])
by_unresolved=sorted(incomplete,key=lambda r:r['unresolved_regions'])
out={'pairs':len(rows),'complete':sum(1 for r in rows if r['complete']),
     'top_by_unowned':by_unowned[:10],'top_by_unresolved':by_unresolved[:10]}
(R/'h38-rerank').mkdir(parents=True,exist_ok=True)
with gzip.open(R/'h38-rerank/h38-scorecard36.json.gz','wt') as f:
    f.write(json.dumps({'all':rows,**out},sort_keys=True,indent=2)+'\n')
print('pairs',out['pairs'],'complete',out['complete'])
print('top_by_unowned:')
for r in out['top_by_unowned']: print(' ',r['pair'],'unowned',r['unowned'],'unresolved',r['unresolved_regions'],'old',r['old_resolved'],'/',r['old_total'],'new',r['new_resolved'],'/',r['new_total'])
print('top_by_unresolved:')
for r in out['top_by_unresolved']: print(' ',r['pair'],'unresolved',r['unresolved_regions'],'unowned',r['unowned'])
