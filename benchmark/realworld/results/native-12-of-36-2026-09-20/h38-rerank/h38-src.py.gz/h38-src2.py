import gzip, json
from collections import Counter
from pathlib import Path
import ijson
cache=Path('benchmark/realworld/cache/native-12-of-36-2026-09-20')
report=cache/'h38-w4-work-128000000/irs-w4-english-2024-to-2025/irs-w4-english-2024-to-2025-native.json.gz'
def res_sources(side, block):
    with gzip.open(report,'rb') as f:
        for item in ijson.items(f, f'assessment.{side}_resolution.item'):
            if item['block']==block and item.get('state')=='equal':
                return item.get('sources',[])
    return []
def source_seq(sources):
    out=[]
    for s in sources:
        out.append((s.get('kind'), s.get('glyph_id'), s.get('page'), s.get('operator_index')))
    return out
old_target=source_seq(res_sources('old',115)); new_target=source_seq(res_sources('new',205))
outcomes=Counter(); established=0; hits=[]
with gzip.open(report,'rb') as f:
    for i,rel in enumerate(ijson.items(f,'assessment.relations.item')):
        outcome=rel.get('outcome'); outcomes[outcome]+=1
        if outcome!='established': continue
        established+=1
        for key,block,target in (('old_span',115,old_target),('new_span',205,new_target)):
            s=rel.get(key)
            if not s or block not in s['blocks']: continue
            seq=source_seq(s.get('sources',[]))
            hits.append({'relation':i,'key':key,'blocks':s['blocks'],'range':s['comparable_range'],
                         'sources':len(seq),'target_sources':len(target),
                         'exact_ordered':seq==target,
                         'target_subset_ordered':all(t in seq for t in target),
                         'kinds':dict(Counter(k for k,_,_,_ in seq)),
                         'assumptions':rel.get('assumptions')})
print('outcomes', dict(outcomes)); print('established', established)
assert established>0, 'positive control failed'
assert 'tentative' in outcomes and 'established' in outcomes, outcomes
print('hits on 115/205', len(hits))
for h in hits: print(json.dumps(h,sort_keys=True)[:300])
Path('/tmp/opencode/h38-src2.json').write_text(json.dumps({'outcomes':dict(outcomes),'established':established,'old_target':old_target,'new_target':new_target,'hits':hits},sort_keys=True,indent=2))
