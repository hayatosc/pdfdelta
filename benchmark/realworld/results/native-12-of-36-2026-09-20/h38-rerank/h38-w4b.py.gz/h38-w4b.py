import gzip, json
from collections import defaultdict
from pathlib import Path
import ijson
cache=Path('benchmark/realworld/cache/native-12-of-36-2026-09-20/h32-suffix-full-iteration-017-native')
report=cache/'irs-w4-english-2024-to-2025/irs-w4-english-2024-to-2025-native.json.gz'
big=None
with gzip.open(report,'rb') as f:
    for item in ijson.items(f,'unresolved_regions.item',use_float=True):
        span=item.get('old_span')
        if span and span['blocks'] and span['blocks'][0]==92:
            big=item; break
print('BIG full span', json.dumps({'blocks':big['old_span']['blocks'],'canonical':big['old_span']['canonical_range'],
      'comparable':big['old_span']['comparable_range'],'separator':big['old_span'].get('block_separator'),
      'pages':big['old_span'].get('pages'),'evidence':big.get('evidence')}, sort_keys=True))
targets=set(big['old_span']['blocks'])
cand115={'block':115,'lo':0,'hi':595}
rel_hits=[]
with gzip.open(report,'rb') as f:
    for i,rel in enumerate(ijson.items(f,'assessment.relations.item',use_float=True)):
        for key in ('old_span','new_span'):
            s=rel.get(key)
            if not s or not s['blocks']: continue
            shared=[b for b in s['blocks'] if b in targets or b==115]
            if shared:
                rel_hits.append({'relation':i,'key':key,'shared':shared,'blocks':s['blocks'],
                                 'canonical':s['canonical_range'],'comparable':s['comparable_range'],
                                 'separator':s.get('block_separator'),'outcome':rel.get('outcome'),
                                 'search':rel.get('search'),'parent':rel.get('parent'),'reasons':rel.get('reasons')})
print('potential relations sharing target blocks (not proven overlap):', len(rel_hits))
for h in rel_hits[:14]: print(' POT', json.dumps(h,sort_keys=True)[:280])
parts=defaultdict(list)
with gzip.open(report,'rb') as f:
    for item in ijson.items(f,'assessment.old_resolution.item',use_float=True):
        if item['block'] in targets or item['block']==115:
            parts[item['block']].append((item['canonical_range']['start'],item['canonical_range']['end'],item.get('state')))
for block in sorted(parts):
    print('PARTITION block',block,parts[block][:10])
