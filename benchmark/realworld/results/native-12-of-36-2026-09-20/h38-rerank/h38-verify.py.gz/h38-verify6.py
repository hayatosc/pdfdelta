import gzip, hashlib, json
from pathlib import Path
REPO=Path('/home/hayato/ghq/github.com/hayatosc/pdfdelta')
D=REPO/'benchmark/realworld/results/native-12-of-36-2026-09-20/h38-rerank'
CACHE=REPO/'benchmark/realworld/cache/native-12-of-36-2026-09-20'
def sha(p):
    h=hashlib.sha256()
    with open(p,'rb') as f:
        for c in iter(lambda: f.read(1<<20), b''): h.update(c)
    return h.hexdigest()
def stream_logical(p):
    h=hashlib.sha256()
    with gzip.open(p,'rb') as f:
        for c in iter(lambda: f.read(1<<20), b''): h.update(c)
    return h.hexdigest()
checks={}
for level in ('32000000','128000000'):
    report=CACHE/f'h38p-w4-{level}/irs-w4-english-2024-to-2025/irs-w4-english-2024-to-2025-native.json.gz'
    runs=json.loads((CACHE/f'h38p-w4-{level}/irs-w4-english-2024-to-2025/runs.json').read_text())['runs'][0]
    meta=runs.get('logical_report_sha256') or runs.get('report_sha256')
    streamed=stream_logical(report)
    archived=json.loads(gzip.open(D/f'h38-w4-work-{level}-summary.json.gz','rt').read())['rows'][0]['report']['sha256']
    phase_summary=json.loads(gzip.open(D/f'h38p-w4-{level}-summary.json.gz','rt').read())
    row=next(r for r in phase_summary['rows'] if r['pair']=='irs-w4-english-2024-to-2025')
    assert streamed==archived==meta, (level, streamed, archived, meta)
    assert sha(report)==row['report']['file_sha256'], (level, sha(report), row['report']['file_sha256'])
    binary=sha(CACHE/f'h38p-w4-{level}/pdfdelta')
    assert binary==phase_summary['binary']['sha256']=='94a2ab9e614e0381883701dacc64e979e517d6018cdcd43be99331ad96d78a4c', (level, binary)
    checks[level]={'streamed_full':streamed,'archived_full':archived,'runs_metadata_full':meta,
                   'match':True,'report_file_sha256':sha(report),'report_file_match':True,
                   'copied_binary_sha256':binary,'binary_match':True,
                   'provenance':'archived untraced summary; raw untraced cache rotated'}
binding=json.loads(gzip.open(D/'h38p-binding.json.gz','rt').read())
binding['checks']=checks
gzip.open(D/'h38p-binding.json.gz','wt').write(json.dumps(binding,sort_keys=True,indent=2)+'\n')
print(json.dumps({k:{'match':v['match'],'binary_match':v['binary_match'],'full':v['streamed_full'][:24]} for k,v in checks.items()},sort_keys=True))
