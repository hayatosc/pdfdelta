import gzip, json, re
from collections import defaultdict
D = 'benchmark/realworld/results/native-12-of-36-2026-09-20/h36-member-eligibility'
rows = [json.loads(l) for l in gzip.open(f'{D}/h36-trace.jsonl.gz','rt').read().splitlines()]
segments = [json.loads(l) for l in gzip.open('benchmark/realworld/results/native-12-of-36-2026-09-20/h33-census-native/census.jsonl.gz','rt').read().splitlines()]
segments = [s for s in segments if s.get('kind') == 'segment' and s['side'] == 0]
assert sum(s['len'] for s in segments) == 1044

round_rows = defaultdict(list); rnd = 0
for row in rows:
    if row['label'] == 'wrapper_established':
        rnd += 1; continue
    round_rows[rnd].append(row)

def blocks_of(detail):
    m = re.search(r'old_block=(\d+)', detail)
    if m: return [int(m.group(1))]
    m = re.search(r'block_indices=\[([\d, ]+)\]', detail)
    if m: return [int(v) for v in m.group(1).split(',')]
    m = re.search(r'blocks=\[([\d, ]+)\]', detail)
    if m: return [int(v) for v in m.group(1).split(',')]
    m = re.search(r'old_blocks=\[([\d, ]+)\]', detail)
    if m: return [int(v) for v in m.group(1).split(',')]
    return []

# side0 view metadata per block (first occurrence per round)
views = {1: {}, 2: {}}
for r in (1, 2):
    for row in round_rows[r]:
        if row['label'] != 'view_with_block32' or 'side=0' not in row['detail']:
            continue
        d = row['detail']
        blocks = blocks_of(d)
        m = re.search(r'block_candidates=\[([a-z, ]+)\]', d)
        cands = [v.strip() == 'true' for v in m.group(1).split(',')] if m else []
        assert len(blocks) == len(cands), (blocks, cands)
        kind = re.search(r'kind=([^ ]+)', d).group(1)
        for pos, b in enumerate(blocks):
            views[r].setdefault(b, {'kind': kind, 'singleton': len(blocks) == 1, 'candidate': cands[pos]})

weighted = defaultdict(int); examples = defaultdict(list)
for s in segments:
    b = s['block']
    meta = views[1].get(b)
    assert meta is not None, ('missing round1 side0 view', b)
    labels = [row['label'] for row in round_rows[1] if row['label'] not in ('view_with_block32','nearest_selected','new_unique_result','nearest_anchor_scan','wrapper_established') and b in blocks_of(row['detail'])]
    assert labels, ('missing terminal', b)
    if labels[0] != 'view_not_untrusted_or_source_bounded':
        continue
    key = f"{meta['kind']} singleton={meta['singleton']} member_candidate={meta['candidate']}"
    weighted[key] += s['len']
    if len(examples[key]) < 8:
        examples[key].append({'block': b, 'range': [s['start'], s['end']], 'len': s['len']})
total = sum(weighted.values())
assert total == 525, total
true_tokens = sum(value for key, value in weighted.items() if 'member_candidate=True' in key)
false_tokens = sum(value for key, value in weighted.items() if 'member_candidate=False' in key)
assert true_tokens == 179, true_tokens
assert false_tokens == 346, false_tokens
result = {'view_rejected_weight': dict(weighted), 'examples': dict(examples),
          'asserts': {'segments': len(segments), 'tokens': sum(s['len'] for s in segments),
                      'view_rejected_total': total, 'member_candidate_true': true_tokens,
                      'member_candidate_false': false_tokens}}
with gzip.open(f'{D}/h36-aggregate.json.gz','wt') as f:
    f.write(json.dumps(result, sort_keys=True, indent=2) + '\n')
print(json.dumps(result['view_rejected_weight'], sort_keys=True))
for key, ex in result['examples'].items():
    print(key, ex[:4])
print('asserts', result['asserts'])
