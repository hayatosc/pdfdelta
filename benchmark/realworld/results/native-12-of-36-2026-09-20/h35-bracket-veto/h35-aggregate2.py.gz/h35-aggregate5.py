import gzip, json, re
from collections import defaultdict
import ijson
D = 'benchmark/realworld/results/native-12-of-36-2026-09-20/h35-bracket-veto'
REPORT = 'benchmark/realworld/cache/native-12-of-36-2026-09-20/h35-bracket-native/irs-1099-misc-2024-to-2025/irs-1099-misc-2024-to-2025-native.json.gz'
rows = [json.loads(l) for l in gzip.open(f'{D}/h35-trace.jsonl.gz','rt').read().splitlines()]
segments = [json.loads(l) for l in gzip.open('benchmark/realworld/results/native-12-of-36-2026-09-20/h33-census-native/census.jsonl.gz','rt').read().splitlines()]
segments = [s for s in segments if s.get('kind') == 'segment' and s['side'] == 0]
assert sum(s['len'] for s in segments) == 1044

nonterminal = {'view_with_block32','nearest_selected','new_unique_result','nearest_anchor_scan','wrapper_established'}
terminal_labels = {
    'view_not_untrusted_or_source_bounded','no_nearest_boundaries','band_empty',
    'old_unique_other_or_none','domain_emitted','new_unique_none_continue',
    'new_view_missing','new_view_not_untrusted_or_source_bounded','new_view_block_mismatch',
    'new_not_positioned','new_range_not_whole','new_geometry_missing','new_page_mismatch',
    'new_candidate_outside_region',
}
terminal_labels |= {l for l in {r['label'] for r in rows} if l.startswith('budget_at_')}

def blocks_of(row):
    d = row['detail']
    m = re.search(r'old_block=(\d+)', d)
    if m: return [int(m.group(1))]
    m = re.search(r'block_indices=\[([\d, ]+)\]', d)
    if m: return [int(v) for v in m.group(1).split(',')]
    m = re.search(r'blocks=\[([\d, ]+)\]', d)
    if m: return [int(v) for v in m.group(1).split(',')]
    m = re.search(r'old_blocks=\[([\d, ]+)\]', d)
    if m: return [int(v) for v in m.group(1).split(',')]
    return []

round_rows = defaultdict(list)
rnd = 0
for row in rows:
    if row['label'] == 'wrapper_established':
        rnd += 1; continue
    round_rows[rnd].append(row)

views = defaultdict(list)
for row in rows:
    if row['label'] == 'view_with_block32':
        for b in blocks_of(row):
            views[b].append(row['detail'])

import hashlib
def sha(p):
    h = hashlib.sha256()
    with open(p, 'rb') as f:
        for c in iter(lambda: f.read(1 << 20), b''): h.update(c)
    return h.hexdigest()
result = {'rounds': {}, 'bindings': {
    'trace_sha256': sha(f'{D}/h35-trace.jsonl.gz'),
    'patch_sha256': sha(f'{D}/h35-hook.patch.gz'),
    'census_sha256': sha('benchmark/realworld/results/native-12-of-36-2026-09-20/h33-census-native/census.jsonl.gz'),
    'report_file_sha256': sha(REPORT),
}}
for r in sorted(round_rows):
    per_block = defaultdict(list)
    for row in round_rows[r]:
        if row['label'] not in terminal_labels: continue
        for b in blocks_of(row):
            per_block[b].append(row['label'])
    covered = 0; dist = defaultdict(int); dup = {}
    for s in segments:
        labels = per_block.get(s['block'], [])
        if labels:
            covered += s['len']; dist[labels[0]] += s['len']
            if len(labels) > 1: dup[s['block']] = labels
    assert not dup, dup
    assert set(per_block) == set(range(294)), (len(per_block), sorted(set(range(294)) - set(per_block))[:5])
    assert len({seg['block'] for seg in segments}) == 49
    assert sum(dist.values()) == 1044, sum(dist.values())
    result['rounds'][r] = {'terminal_tokens': covered, 'unknown_tokens': 1044 - covered,
                           'weighted': dict(dist), 'duplicate_terminals': dup,
                           'total_old_blocks': 294, 'terminal_blocks': len(per_block),
                           'residual_blocks': 49}

# 525-token view-rejection breakdown by view kind/source_bounded/order_certified
view_weight = defaultdict(int); view_examples = defaultdict(list)
for s in segments:
    labels = [row['label'] for row in round_rows[1] if row['label'] not in nonterminal and row['label'] in terminal_labels and s['block'] in blocks_of(row)]
    if not labels or labels[0] != 'view_not_untrusted_or_source_bounded':
        continue
    side0 = [v for v in views.get(s['block'], []) if 'side=0' in v]
    assert side0, ('missing side0 view', s['block'])
    detail = side0[0]
    kind = re.search(r'kind=([^ ]+)', detail)
    assert kind, ('missing kind', s['block'], detail[:60])
    kind_text = kind.group(1)
    trusted = 'Trusted' in kind_text
    sb = 'source_bounded=true' in detail
    oc = 'order_certified=true' in detail
    singleton = 'block_indices=[1]' in detail or bool(re.search(r'block_indices=\[\d+\]', detail))
    key = f"kind={'Trusted' if trusted else 'Untrusted'} singleton={singleton} source_bounded={sb} order_certified={oc}"
    view_weight[key] += s['len']
    if len(view_examples[key]) < 6:
        view_examples[key].append({'block': s['block'], 'range': [s['start'], s['end']], 'len': s['len']})

# report spans for the view-rejected blocks
target_blocks = set()
for s in segments:
    labels = [row['label'] for row in round_rows[1] if row['label'] not in nonterminal and row['label'] in terminal_labels and s['block'] in blocks_of(row)]
    if labels and labels[0] == 'view_not_untrusted_or_source_bounded':
        target_blocks.add(s['block'])
span_info = {}
with gzip.open(REPORT, 'rb') as handle:
    for item in ijson.items(handle, 'unresolved_regions.item', use_float=True):
        span = item.get('old_span')
        if span and isinstance(span.get('blocks'), list) and len(span['blocks']) == 1 and span['blocks'][0] in target_blocks:
            b = span['blocks'][0]
            span_info.setdefault(b, []).append({
                'evidence': item.get('evidence'),
                'text_len': len(span.get('text') or ''),
                'text_head': (span.get('text') or '')[:60],
                'sources': len(span.get('sources', [])),
                'pages': span.get('pages'),
            })

# old32 below candidates: strict below from nearest_selected bounds
selected = [r for r in rows if r['label'] == 'nearest_selected']
below = []
for r in selected:
    m = re.search(r'old_block=(\d+).*candidate_bounds=\(([-\d.]+), ([-\d.]+), ([-\d.]+), ([-\d.]+)\).*above_old=\(([-\d.]+), ([-\d.]+), ([-\d.]+), ([-\d.]+)\).*below_old=\(([-\d.]+), ([-\d.]+), ([-\d.]+), ([-\d.]+)\)', r['detail'])
    if not m: continue
    old_block = int(m.group(1)); cb = list(map(float, m.group(2,3,4,5))); ab = list(map(float, m.group(6,7,8,9))); bl = list(map(float, m.group(10,11,12,13)))
    if old_block == 32:
        below.append({'round': 1 if r in round_rows[1] else 2, 'candidate_min_y': cb[1], 'above_y': ab[1], 'chosen_below_y': bl[1], 'chosen_below_x': [bl[0], bl[2]]})

result['view_rejection_weight'] = dict(view_weight)
result['view_rejection_examples'] = dict(view_examples)
result['view_rejected_span_info'] = span_info
result['old32_selected'] = below
with gzip.open(f'{D}/h35-aggregate2.json.gz','wt') as f:
    f.write(json.dumps(result, sort_keys=True, indent=2) + '\n')
print('rounds', json.dumps(result['rounds'], sort_keys=True)[:600])
print('view_weight', json.dumps(result['view_rejection_weight'], sort_keys=True))
print('span_info blocks', len(span_info), 'sample', json.dumps(list(span_info.items())[:2], sort_keys=True)[:300])
print('old32 selected', below)
